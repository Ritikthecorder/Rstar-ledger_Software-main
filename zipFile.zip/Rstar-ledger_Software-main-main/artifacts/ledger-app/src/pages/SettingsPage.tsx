import { useState, useEffect, useRef } from "react";
import { useSettings, useUpsertSettings } from "@/hooks/useSettings";
import { useSettingsStore } from "@/store/settings";
import { useBusinessProfileStore } from "@/store/businessProfile";
import { useAuthStore } from "@/store/auth";
import { useTheme } from "@/components/ThemeProvider";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Moon, Sun, Monitor, LogOut, Save, Upload, X, ImageIcon } from "lucide-react";

const CURRENCIES = [
  { code: "INR", label: "Indian Rupee (₹)" },
  { code: "USD", label: "US Dollar ($)" },
  { code: "EUR", label: "Euro (€)" },
  { code: "GBP", label: "British Pound (£)" },
  { code: "AED", label: "UAE Dirham (AED)" },
  { code: "SGD", label: "Singapore Dollar (S$)" },
];

export default function SettingsPage() {
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const user = useAuthStore((s) => s.user);
  const signOut = useAuthStore((s) => s.signOut);
  const settings = useSettingsStore((s) => s.settings);
  const { description, watermarkDataUrl, setDescription, setWatermark } = useBusinessProfileStore();

  useSettings();
  const upsertSettings = useUpsertSettings();

  const [businessName, setBusinessName] = useState(settings?.business_name ?? "");
  const [currency, setCurrency] = useState(settings?.currency ?? "INR");
  const [localDesc, setLocalDesc] = useState(description);
  const watermarkInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (settings) {
      setBusinessName(settings.business_name ?? "");
      setCurrency(settings.currency ?? "INR");
    }
  }, [settings]);

  useEffect(() => {
    setLocalDesc(description);
  }, [description]);

  const handleSave = async () => {
    try {
      await upsertSettings.mutateAsync({ business_name: businessName, currency });
      setDescription(localDesc);
      toast({ title: "Settings saved" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleWatermarkUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast({ title: "Please upload an image file", variant: "destructive" });
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast({ title: "Image must be under 2MB", variant: "destructive" });
      return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      setWatermark(result);
      toast({ title: "Watermark uploaded" });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleRemoveWatermark = () => {
    setWatermark(null);
    toast({ title: "Watermark removed" });
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground text-sm mt-1">Manage your account and preferences</p>
      </div>

      {/* Account */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Account</CardTitle>
          <CardDescription>Your account information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-12 w-12">
              <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                {user?.email?.charAt(0).toUpperCase() ?? "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{user?.email}</p>
              <Badge variant="secondary" className="mt-1 text-xs">Free Plan</Badge>
            </div>
          </div>
          <Separator />
          <Button variant="destructive" onClick={signOut} className="gap-2">
            <LogOut className="h-4 w-4" />Sign Out
          </Button>
        </CardContent>
      </Card>

      {/* Business Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Business Settings</CardTitle>
          <CardDescription>These details appear on all printed ledgers and statements</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Business Name */}
          <div className="space-y-1.5">
            <Label>Business Name</Label>
            <Input
              className="h-10"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="Your Business Name"
            />
          </div>

          {/* Currency */}
          <div className="space-y-1.5">
            <Label>Currency</Label>
            <Select value={currency} onValueChange={setCurrency}>
              <SelectTrigger className="h-10">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CURRENCIES.map((c) => (
                  <SelectItem key={c.code} value={c.code}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Business Description */}
          <div className="space-y-1.5">
            <Label>Business Description</Label>
            <Textarea
              value={localDesc}
              onChange={(e) => setLocalDesc(e.target.value)}
              placeholder="e.g. GST No: 27AXXXX · Address: 123 MG Road, Mumbai · Ph: +91 9876543210"
              rows={3}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground">
              This text prints below your business name on every ledger and statement
            </p>
          </div>

          {/* Watermark */}
          <div className="space-y-3">
            <div>
              <Label>Print Watermark</Label>
              <p className="text-xs text-muted-foreground mt-0.5">
                Upload your logo or stamp — it appears as a faint watermark behind the print content
              </p>
            </div>

            {watermarkDataUrl ? (
              <div className="flex items-center gap-4 p-3 rounded-xl border bg-muted/30">
                <div className="h-16 w-16 rounded-lg border bg-white flex items-center justify-center overflow-hidden shrink-0">
                  <img
                    src={watermarkDataUrl}
                    alt="Watermark preview"
                    className="h-full w-full object-contain p-1"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">Watermark uploaded</p>
                  <p className="text-xs text-muted-foreground">Will appear behind the print content</p>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5"
                    onClick={() => watermarkInputRef.current?.click()}
                  >
                    <Upload className="h-3.5 w-3.5" />Change
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="gap-1.5 text-destructive hover:text-destructive"
                    onClick={handleRemoveWatermark}
                  >
                    <X className="h-3.5 w-3.5" />Remove
                  </Button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => watermarkInputRef.current?.click()}
                className="w-full flex flex-col items-center justify-center gap-3 border-2 border-dashed rounded-xl py-8 text-muted-foreground hover:border-primary/50 hover:text-foreground transition-colors"
              >
                <div className="p-3 rounded-full bg-muted">
                  <ImageIcon className="h-5 w-5" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium">Click to upload watermark</p>
                  <p className="text-xs mt-0.5">PNG, JPG, SVG · Max 2MB</p>
                </div>
              </button>
            )}

            <input
              ref={watermarkInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleWatermarkUpload}
            />
          </div>

          <Button onClick={handleSave} disabled={upsertSettings.isPending} className="gap-2">
            <Save className="h-4 w-4" />
            {upsertSettings.isPending ? "Saving..." : "Save Settings"}
          </Button>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Appearance</CardTitle>
          <CardDescription>Choose your preferred theme</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            {[
              { value: "light", label: "Light", icon: Sun },
              { value: "dark", label: "Dark", icon: Moon },
              { value: "system", label: "System", icon: Monitor },
            ].map((t) => (
              <button
                key={t.value}
                onClick={() => setTheme(t.value as any)}
                className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all flex-1 ${
                  theme === t.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                }`}
              >
                <t.icon className={`h-5 w-5 ${theme === t.value ? "text-primary" : "text-muted-foreground"}`} />
                <span className={`text-sm font-medium ${theme === t.value ? "text-primary" : "text-muted-foreground"}`}>
                  {t.label}
                </span>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

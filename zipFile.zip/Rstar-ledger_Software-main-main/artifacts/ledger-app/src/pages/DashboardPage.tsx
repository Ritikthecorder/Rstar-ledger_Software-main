import { useDashboardStats } from "@/hooks/useTransactions";
import { useSettings } from "@/hooks/useSettings";
import { useSettingsStore } from "@/store/settings";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/export";
import { TrendingUp, TrendingDown, Wallet, Users } from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import { useTransactions } from "@/hooks/useTransactions";

export default function DashboardPage() {
  useSettings();
  const settings = useSettingsStore((s) => s.settings);
  const currency = settings?.currency ?? "INR";

  const { data: stats, isLoading: statsLoading } = useDashboardStats();
  const { data: recentData } = useTransactions({ page: 1, pageSize: 10 });
  const recentTransactions = recentData?.data ?? [];

  const statCards = [
    {
      title: "Total Balance",
      value: stats ? formatCurrency(stats.balance, currency) : "-",
      icon: Wallet,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      title: "Total Credit",
      value: stats ? formatCurrency(stats.totalCredit, currency) : "-",
      icon: TrendingUp,
      color: "text-green-600",
      bg: "bg-green-50 dark:bg-green-950",
    },
    {
      title: "Total Debit",
      value: stats ? formatCurrency(stats.totalDebit, currency) : "-",
      icon: TrendingDown,
      color: "text-red-600",
      bg: "bg-red-50 dark:bg-red-950",
    },
    {
      title: "Customers",
      value: stats ? String(stats.customerCount) : "-",
      icon: Users,
      color: "text-blue-600",
      bg: "bg-blue-50 dark:bg-blue-950",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">Overview of your ledger</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => (
          <Card key={card.title}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{card.title}</p>
                  {statsLoading ? (
                    <Skeleton className="h-8 w-28 mt-1" />
                  ) : (
                    <p className="text-2xl font-bold mt-1">{card.value}</p>
                  )}
                </div>
                <div className={`p-3 rounded-full ${card.bg}`}>
                  <card.icon className={`h-5 w-5 ${card.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-base">Monthly Credit vs Debit</CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? (
              <Skeleton className="h-64 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={stats?.chartData ?? []}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 11 }}
                    tickFormatter={(v) => {
                      const [y, m] = v.split("-");
                      return `${["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][parseInt(m)-1]} ${y.slice(2)}`;
                    }}
                  />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `${(v/1000).toFixed(0)}k`} />
                  <Tooltip
                    formatter={(value: number) => formatCurrency(value, currency)}
                  />
                  <Legend />
                  <Bar dataKey="credit" name="Credit" fill="#22c55e" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="debit" name="Debit" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentTransactions.slice(0, 8).map((t) => (
                <div key={t.id} className="flex items-center justify-between text-sm">
                  <div className="min-w-0">
                    <p className="font-medium truncate">
                      {(t as any).customers?.name ?? "Unknown"}
                    </p>
                    <p className="text-muted-foreground text-xs">{t.date}</p>
                  </div>
                  <span
                    className={`font-semibold ml-2 shrink-0 ${
                      t.type === "credit" ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {t.type === "credit" ? "+" : "-"}
                    {formatCurrency(Number(t.amount), currency)}
                  </span>
                </div>
              ))}
              {recentTransactions.length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-8">
                  No transactions yet
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

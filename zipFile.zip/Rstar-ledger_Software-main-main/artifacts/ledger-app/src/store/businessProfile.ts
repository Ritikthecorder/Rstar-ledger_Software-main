import { create } from "zustand";
import { persist } from "zustand/middleware";

interface BusinessProfileState {
  description: string;
  watermarkDataUrl: string | null;
  setDescription: (desc: string) => void;
  setWatermark: (dataUrl: string | null) => void;
}

export const useBusinessProfileStore = create<BusinessProfileState>()(
  persist(
    (set) => ({
      description: "",
      watermarkDataUrl: null,
      setDescription: (description) => set({ description }),
      setWatermark: (watermarkDataUrl) => set({ watermarkDataUrl }),
    }),
    { name: "ledger-business-profile" }
  )
);
